package crop;


import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author BHAWESHWARI
 */
public class database {
    public Statement stmt;
    public Connection con;
    
            public database(){
            
                
                try{  
               Class.forName("com.mysql.jdbc.Driver");  
               String url = "jdbc:mysql://localhost:3306/crop";
               String pass = "Rushi";
               con=DriverManager.getConnection(url,"root",pass);  
        //here sonoo is database name, root is username and password  
                stmt = (Statement) con.createStatement();
        }
           catch(Exception e){ System.out.println(e);} 
            
            } 
        }